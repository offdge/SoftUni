﻿namespace DungeonsAndCodeWizards.Entities.Inventory
{
	public class Backpack : Bag
	{
	}
}
