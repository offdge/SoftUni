﻿namespace DungeonsAndCodeWizards.Entities.Characters.Contracts
{
	public interface IHealable
	{
		void Heal(Character character);
	}
}