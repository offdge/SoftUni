﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards
{
    public class Satchel : Bag
    {
        public Satchel() : base(20)
        {
        }
    }
}
