﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards
{
    public class HealthPotion : Item
    {
        public HealthPotion() : base(5)
        {
        }
    }
}
