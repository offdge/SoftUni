﻿namespace DungeonsAndCodeWizards
{
	public interface IAttackable
	{
		void Attack(Character character);
	}
}